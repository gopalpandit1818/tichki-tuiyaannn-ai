TICHKI TUIYAANNN AI — Netlify project

Files:
- index.html: chatbot interface
- netlify/functions/chat.mjs: secure server-side Hugging Face API call
- netlify.toml: Netlify configuration

IMPORTANT:
1. Do not put your Hugging Face token in index.html or share it in chat.
2. In Hugging Face, create a fine-grained token with "Make calls to Inference Providers" permission.
3. In Netlify site settings, add environment variable:
   Key: HF_TOKEN
   Value: your private Hugging Face token
   Scope: Functions (or all scopes)
4. Redeploy the project after adding the environment variable.
5. Hugging Face Free accounts currently include a small monthly inference credit (listed as $0.10, subject to change). It is not unlimited. Do not enable/purchase extra credits if you want to keep it free.

Deployment:
Deploy this project using a Netlify build/deploy flow that processes netlify/functions. The Netlify Drop manual upload of only index.html will NOT deploy the function. Connecting the project folder/repository for a Netlify build is the reliable route.
