export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Use POST for chat messages." }, { status: 405 });
  }

  const token = process.env.HF_TOKEN;
  if (!token) {
    return Response.json({ error: "Server setup is incomplete: HF_TOKEN is missing in Netlify environment variables." }, { status: 500 });
  }

  try {
    const body = await request.json();
    const incoming = Array.isArray(body.messages) ? body.messages : [];
    const messages = incoming
      .filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-12)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));

    if (!messages.length || messages[messages.length - 1].role !== "user") {
      return Response.json({ error: "Please send a message first." }, { status: 400 });
    }

    const response = await fetch("https://router.huggingface.co/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "meta-llama/Llama-3.1-8B-Instruct:fastest",
        messages: [
          {
            role: "system",
            content: "You are TICHKI TUIYAANNN AI, a friendly and helpful assistant. Reply in the language the user uses, including Hindi or English. Be clear, respectful, age-appropriate, and concise. Never claim to have performed actions you have not performed."
          },
          ...messages
        ],
        max_tokens: 450,
        temperature: 0.7
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("Hugging Face API error:", data);
      return Response.json({
        error: response.status === 401 || response.status === 403
          ? "Hugging Face token permission issue. Check that the token allows Inference Providers."
          : response.status === 402
          ? "Free inference credits may be used up. Check your Hugging Face billing/usage page."
          : "AI provider is temporarily unavailable. Please try again later."
      }, { status: response.status === 429 ? 429 : 502 });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return Response.json({ error: "The AI returned an empty response. Please try again." }, { status: 502 });
    }
    return Response.json({ reply: reply.trim() });
  } catch (error) {
    console.error("Chat function error:", error);
    return Response.json({ error: "Could not process that message. Please try again." }, { status: 500 });
  }
};